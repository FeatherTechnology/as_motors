	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Meta -->
		<meta name="description" content="Feather Rasi Project">
		<meta name="author" content="Feather Rasi Project">
		<link rel="shortcut icon" href="img/fav.png" />

		<!-- Title -->
		<title>AS MOTORS </title>


			<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap css -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Icomoon Font Icons css -->
		<link rel="stylesheet" href="fonts/style.css">
		<!-- Main css -->
		<link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" href="vendor/customcss/customstyle.css" />
		<link rel="stylesheet" href="vendor/customcss/tabstyle.css" />

		<!-- *************
			************ Vendor Css Files *************
		************ -->
		<!-- DateRange css -->
	
<!-- DateRange css -->
<link rel="stylesheet" href="vendor/daterange/daterange.css" />
<!-- Datepicker css -->
<link rel="stylesheet" href="vendor/datepicker/css/classic.css" />
<link rel="stylesheet" href="vendor/datepicker/css/classic.date.css" />

<link rel="stylesheet" type="text/css" href="cssd/datatables.min.css" />

<script src="vendor/bs-select/bs-select.min.js"></script>
<style>
        .dataTables_length {
            margin-bottom: 30px;
        }
        
        .dataTables_length select {
            border: 1px solid #e4e4e4;
        }
        
        .dt-buttons a {
            margin-left: 12px;
            font-size: 12px;
            padding: 6px;
            border: 1px solid #e4e4e4;
            background: #FFF;
            box-shadow: 0px 0px 14px 0px #ececec;
        }
        
        .dataTables_filter input {
            border: 1px solid #e4e4e4;
        }
        
        .table-striped tbody tr {
            line-height: 30px;
        }
 </style>	
		<!-- Bootstrap Select CSS -->
		<link rel="stylesheet" href="vendor/bs-select/bs-select.css" />
	</head>